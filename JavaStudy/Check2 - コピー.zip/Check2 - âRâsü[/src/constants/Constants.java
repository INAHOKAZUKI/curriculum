package constants;

public class Constants {

    //定数（名前）
    public static final String CHECK_CLASS_JAVA = "java吉";
    public static final String CHECK_CLASS_HOGE = "hoge";
    public static final String CHECK_CLASS_R2D2 = "R2D2";
    public static final String CHECK_CLASS_LUKE = "ルーク";

}